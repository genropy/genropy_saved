#!/usr/bin/env python
# -*- encoding: utf-8 -*-

from gnr.web.gnrwebpage import BaseComponent

class Mixin(BaseComponent):
    